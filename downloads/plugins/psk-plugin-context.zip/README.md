# Productside Playbook: Context

This is a Claude plugin package. Use Claude's custom-plugin installation flow. A plugin ZIP is not the three-document Project kit.

Version: 0.1.0. Source fingerprint: f9a615d1ee8aed08.

## Try it

After installation, find the included skills in your assistant. Ask for a skill by its psk- identifier, or select it from the available skills list.

> Use psk-outcome-strategy-discussion for [my product and customer]. Start in Guided mode and ask one question at a time.

Guided teaches while completing the work. Expert uses supplied context and offers coaching on demand. Discovery sketches or simulates with synthesized assumptions labeled. People own research and decisions.

## Included skills (4)

- [Outcome & Strategy Discussion](skills/psk-outcome-strategy-discussion/SKILL.md) (`psk-outcome-strategy-discussion`)
- [Stakeholder Alignment](skills/psk-stakeholder-alignment/SKILL.md) (`psk-stakeholder-alignment`)
- [Outcome Tree (Sections One and Two)](skills/psk-outcome-tree/SKILL.md) (`psk-outcome-tree`)
- [Market Selection & Sizing](skills/psk-market-selection-sizing/SKILL.md) (`psk-market-selection-sizing`)
Outcome Tree Sections One and Two share one skill, packaged in Context and the full library. The Blueprint navigator is in the full library only.

## Status and license

Content follows the November 2026 B2B work-in-progress Playbook, not yet ratified. Archive checks and plugin-manifest validation do not establish live installation or behavioral results.

Based on materials from Productside, licensed under CC BY-NC-SA 4.0 with Additional Internal Business Use Permissions. See [LICENSE](LICENSE). [Setup and current validation status](https://github.com/deanpeters/ps-playbook-skills/tree/main/downloads).
