# Productside Playbook: Create

Add this collection through Claude's Plugins page using its custom-plugin upload option. Keep the ZIP closed for upload. A plugin ZIP is not the three-document Project kit.

Package version: 0.1.0.

## Try it

After installation, find the included skills in your assistant. Ask for a skill by its psk- identifier, or select it from the available skills list.

> Use psk-outcome-roadmap for [my product and customer]. Start in Guided mode and ask one question at a time.

Guided teaches while completing the work. Expert uses supplied context and offers coaching on demand. Discovery sketches or simulates with synthesized assumptions labeled. People own research and decisions.

## Included skills (5)

- [Outcome-Based Roadmap & Release Plan](skills/psk-outcome-roadmap/SKILL.md) (`psk-outcome-roadmap`)
- [Tiny Acts of Discovery](skills/psk-tiny-acts-discovery/SKILL.md) (`psk-tiny-acts-discovery`)
- [Output Prioritization](skills/psk-output-prioritization/SKILL.md) (`psk-output-prioritization`)
- [Go-to-Market Enablement](skills/psk-go-to-market/SKILL.md) (`psk-go-to-market`)
- [Product Readiness Testing](skills/psk-product-readiness/SKILL.md) (`psk-product-readiness`)
Outcome Tree Sections One and Two share one skill, packaged in Context and the full library. The Blueprint navigator is in the full library only.

## Status and license

Content follows the November 2026 B2B work-in-progress Playbook, not yet ratified. The package files have been checked for completeness. Live installation and AI responses still need testing; try one Play before sharing a setup.

Based on materials from Productside, licensed under CC BY-NC-SA 4.0 with Additional Internal Business Use Permissions. See [LICENSE](LICENSE). [Setup and current validation status](https://github.com/deanpeters/ps-playbook-skills/tree/main/downloads).
