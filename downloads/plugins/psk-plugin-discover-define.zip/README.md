# Productside Playbook: Discover + Define

Add this collection through Claude's Plugins page using its custom-plugin upload option. Keep the ZIP closed for upload. A plugin ZIP is not the three-document Project kit.

Package version: 0.1.0.

## Try it

After installation, find the included skills in your assistant. Ask for a skill by its psk- identifier, or select it from the available skills list.

> Use psk-exploring-solution-space for [my product and customer]. Start in Guided mode and ask one question at a time.

Guided teaches while completing the work. Expert uses supplied context and offers coaching on demand. Discovery sketches or simulates with synthesized assumptions labeled. People own research and decisions.

## Included skills (7)

- [Exploring the Solution Space](skills/psk-exploring-solution-space/SKILL.md) (`psk-exploring-solution-space`)
- [Solution Hypothesis](skills/psk-solution-hypothesis/SKILL.md) (`psk-solution-hypothesis`)
- [Positioning Statement](skills/psk-positioning-statement/SKILL.md) (`psk-positioning-statement`)
- [Lo-fi Experimentation](skills/psk-lofi-experimentation/SKILL.md) (`psk-lofi-experimentation`)
- [Storyboarding](skills/psk-storyboarding/SKILL.md) (`psk-storyboarding`)
- [Risk Assessment](skills/psk-risk-assessment/SKILL.md) (`psk-risk-assessment`)
- [Product Outcome Canvas](skills/psk-product-outcome-canvas/SKILL.md) (`psk-product-outcome-canvas`)
Outcome Tree Sections One and Two share one skill, packaged in Context and the full library. The Blueprint navigator is in the full library only.

## Status and license

Content follows the November 2026 B2B work-in-progress Playbook, not yet ratified. The package files have been checked for completeness. Live installation and AI responses still need testing; try one Play before sharing a setup.

Based on materials from Productside, licensed under CC BY-NC-SA 4.0 with Additional Internal Business Use Permissions. See [LICENSE](LICENSE). [Setup and current validation status](https://github.com/deanpeters/ps-playbook-skills/tree/main/downloads).
