# Productside Playbook: Create

Unpack this ZIP to use the skills and prompts as files. A bundle does not install itself.

Version: 0.1.0. Source fingerprint: 04df3ad115aeea88.

## Try it

Open a prompt under prompts/ and copy its text box into your AI chat. Or attach a chosen skills/psk-.../SKILL.md, which includes its template and examples.

> Use psk-outcome-roadmap for [my product and customer]. Start in Guided mode and ask one question at a time.

Guided teaches while completing the work. Expert uses supplied context and offers coaching on demand. Discovery sketches or simulates with synthesized assumptions labeled. People own research and decisions.

## Included skills (5)

- [Outcome-Based Roadmap & Release Plan](skills/psk-outcome-roadmap/SKILL.md) (`psk-outcome-roadmap`)
- [Tiny Acts of Discovery](skills/psk-tiny-acts-discovery/SKILL.md) (`psk-tiny-acts-discovery`)
- [Output Prioritization](skills/psk-output-prioritization/SKILL.md) (`psk-output-prioritization`)
- [Go-to-Market Enablement](skills/psk-go-to-market/SKILL.md) (`psk-go-to-market`)
- [Product Readiness Testing](skills/psk-product-readiness/SKILL.md) (`psk-product-readiness`)

Includes 7 matching prompt files. The original Playbook tasks and library-added interaction instructions are labeled separately.

For a shared prompt library, copy the prompts/ folder to an approved SharePoint library, shared drive, or wiki. Add a simple index and keep one reviewed version for your team. A shared folder does not install skills or automatically connect an AI assistant.

Outcome Tree Sections One and Two share one skill, packaged in Context and the full library. The Blueprint navigator is in the full library only.

## Status and license

Content follows the November 2026 B2B work-in-progress Playbook, not yet ratified. Archive checks and plugin-manifest validation do not establish live installation or behavioral results.

Based on materials from Productside, licensed under CC BY-NC-SA 4.0 with Additional Internal Business Use Permissions. See [LICENSE](LICENSE). [Setup and current validation status](https://github.com/deanpeters/ps-playbook-skills/tree/main/downloads).
