# Productside Playbook: Project kit

Start with [project/README.md](project/README.md). It explains Claude Projects, ChatGPT Projects, Microsoft 365 Copilot Notebooks or Agents, and Gemini Skills (formerly Gems).

Unpack this ZIP. Add the three documents in project/uploads/ as reference content in your tool's supported format. Paste project/project-instructions-compact.txt into its instructions field; project/project-instructions.md is the detailed reference. Follow the platform-specific format notes in the setup guide, including plain-text copies for Microsoft 365 Agent uploads.

Version: 0.1.0. Source fingerprint: 887b01b5a1033a7c.

Uploaded files do not update automatically from GitHub. Replace all three sources together and test both a prompt and a full Play before sharing. This kit is reference content, not a Claude plugin or Gemini SKILL.md upload package.

Based on materials from Productside. See [LICENSE](LICENSE) for CC BY-NC-SA 4.0 with Additional Internal Business Use Permissions. Source content is work-in-progress, not yet ratified. Live platform installation and behavior remain unverified.
