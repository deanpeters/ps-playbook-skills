# Productside Playbook: Project kit

Start with [projects/README.md](projects/README.md). It explains Claude Projects, ChatGPT Projects, Microsoft 365 Copilot Notebooks or Agents, and Gemini Skills (formerly Gems).

On a Mac, double-click the ZIP. On Windows, right-click it and choose Extract All. Open projects/README.md for step-by-step setup. Add the three documents in projects/uploads/ as reference content in your tool's supported format. Paste projects/project-instructions-compact.txt into its instructions field; projects/project-instructions.md is the detailed reference. Follow the platform-specific format notes in the setup guide, including plain-text copies for Microsoft 365 Agent uploads.

Package version: 0.1.0.

Uploaded files do not update automatically from GitHub. Replace all three sources together and test both a prompt and a full Play before sharing. This kit is reference content, not a Claude plugin or Gemini SKILL.md upload package.

Based on materials from Productside. See [LICENSE](LICENSE) for CC BY-NC-SA 4.0 with Additional Internal Business Use Permissions. Source content is work-in-progress, not yet ratified. Try the example requests in the setup guide before sharing with your team. Live setup and responses have not yet been tested.
