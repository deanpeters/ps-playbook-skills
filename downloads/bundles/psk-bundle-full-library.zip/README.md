# Productside Playbook: Full library

Open this collection to choose a prompt or a full Play for your AI chat. No coding required. On a Mac, double-click the ZIP. On Windows, right-click it and choose Extract All.

Package version: 0.1.0.

## Try it

Open the prompts folder, choose a task, and open a prompt document. Copy the whole text box into your AI chat. For a full Play, open the skills folder, choose a Play, and attach its SKILL.md document to your chat. That document includes its template and examples.

> Use psk-blueprint-advisor for [my product and customer]. Start in Guided mode and ask one question at a time.

Guided teaches while completing the work. Expert uses supplied context and offers coaching on demand. Discovery sketches or simulates with synthesized assumptions labeled. People own research and decisions.

## Included skills (25)

- [Blueprint navigator](skills/psk-blueprint-advisor/SKILL.md) (`psk-blueprint-advisor`)
- [Outcome & Strategy Discussion](skills/psk-outcome-strategy-discussion/SKILL.md) (`psk-outcome-strategy-discussion`)
- [Stakeholder Alignment](skills/psk-stakeholder-alignment/SKILL.md) (`psk-stakeholder-alignment`)
- [Outcome Tree (Sections One and Two)](skills/psk-outcome-tree/SKILL.md) (`psk-outcome-tree`)
- [Market Selection & Sizing](skills/psk-market-selection-sizing/SKILL.md) (`psk-market-selection-sizing`)
- [Jobs-to-Be-Done & Outcomes](skills/psk-jobs-to-be-done/SKILL.md) (`psk-jobs-to-be-done`)
- [Personas & Proto-Personas](skills/psk-proto-persona/SKILL.md) (`psk-proto-persona`)
- [Empathy Interviews](skills/psk-empathy-interviews/SKILL.md) (`psk-empathy-interviews`)
- [Affinity Mapping](skills/psk-affinity-mapping/SKILL.md) (`psk-affinity-mapping`)
- [Problem Identification](skills/psk-problem-identification/SKILL.md) (`psk-problem-identification`)
- [Framing the Problem](skills/psk-framing-the-problem/SKILL.md) (`psk-framing-the-problem`)
- [Exploring the Solution Space](skills/psk-exploring-solution-space/SKILL.md) (`psk-exploring-solution-space`)
- [Solution Hypothesis](skills/psk-solution-hypothesis/SKILL.md) (`psk-solution-hypothesis`)
- [Positioning Statement](skills/psk-positioning-statement/SKILL.md) (`psk-positioning-statement`)
- [Lo-fi Experimentation](skills/psk-lofi-experimentation/SKILL.md) (`psk-lofi-experimentation`)
- [Storyboarding](skills/psk-storyboarding/SKILL.md) (`psk-storyboarding`)
- [Risk Assessment](skills/psk-risk-assessment/SKILL.md) (`psk-risk-assessment`)
- [Product Outcome Canvas](skills/psk-product-outcome-canvas/SKILL.md) (`psk-product-outcome-canvas`)
- [Outcome-Based Roadmap & Release Plan](skills/psk-outcome-roadmap/SKILL.md) (`psk-outcome-roadmap`)
- [Tiny Acts of Discovery](skills/psk-tiny-acts-discovery/SKILL.md) (`psk-tiny-acts-discovery`)
- [Output Prioritization](skills/psk-output-prioritization/SKILL.md) (`psk-output-prioritization`)
- [Go-to-Market Enablement](skills/psk-go-to-market/SKILL.md) (`psk-go-to-market`)
- [Product Readiness Testing](skills/psk-product-readiness/SKILL.md) (`psk-product-readiness`)
- [Measuring Outcomes](skills/psk-measuring-outcomes/SKILL.md) (`psk-measuring-outcomes`)
- [Process Retrospective](skills/psk-process-retrospective/SKILL.md) (`psk-process-retrospective`)

Includes 38 matching prompt files. The original Playbook tasks and library-added interaction instructions are labeled separately.

For a shared prompt library, copy the prompts/ folder to an approved SharePoint library, shared drive, or wiki. Add a simple index and keep one reviewed version for your team. A shared folder does not install skills or automatically connect an AI assistant.

Outcome Tree Sections One and Two share one skill, packaged in Context and the full library. The Blueprint navigator is in the full library only.

## Status and license

Content follows the November 2026 B2B work-in-progress Playbook, not yet ratified. The package files have been checked for completeness. Live installation and AI responses still need testing; try one Play before sharing a setup.

Based on materials from Productside, licensed under CC BY-NC-SA 4.0 with Additional Internal Business Use Permissions. See [LICENSE](LICENSE). [Setup and current validation status](https://github.com/deanpeters/ps-playbook-skills/tree/main/downloads).
