# Productside Playbook: Context

Unpack this ZIP to use the skills and prompts as files. A bundle does not install itself.

Version: 0.1.0. Source fingerprint: 9c270c80cb33d8a5.

## Try it

Open a prompt under prompts/ and copy its text box into your AI chat. Or attach a chosen skills/psk-.../SKILL.md, which includes its template and examples.

> Use psk-outcome-strategy-discussion for [my product and customer]. Start in Guided mode and ask one question at a time.

Guided teaches while completing the work. Expert uses supplied context and offers coaching on demand. Discovery sketches or simulates with synthesized assumptions labeled. People own research and decisions.

## Included skills (4)

- [Outcome & Strategy Discussion](skills/psk-outcome-strategy-discussion/SKILL.md) (`psk-outcome-strategy-discussion`)
- [Stakeholder Alignment](skills/psk-stakeholder-alignment/SKILL.md) (`psk-stakeholder-alignment`)
- [Outcome Tree (Sections One and Two)](skills/psk-outcome-tree/SKILL.md) (`psk-outcome-tree`)
- [Market Selection & Sizing](skills/psk-market-selection-sizing/SKILL.md) (`psk-market-selection-sizing`)

Includes 8 matching prompt files. The original Playbook tasks and library-added interaction instructions are labeled separately.

For a shared prompt library, copy the prompts/ folder to an approved SharePoint library, shared drive, or wiki. Add a simple index and keep one reviewed version for your team. A shared folder does not install skills or automatically connect an AI assistant.

Outcome Tree Sections One and Two share one skill, packaged in Context and the full library. The Blueprint navigator is in the full library only.

## Status and license

Content follows the November 2026 B2B work-in-progress Playbook, not yet ratified. Archive checks and plugin-manifest validation do not establish live installation or behavioral results.

Based on materials from Productside, licensed under CC BY-NC-SA 4.0 with Additional Internal Business Use Permissions. See [LICENSE](LICENSE). [Setup and current validation status](https://github.com/deanpeters/ps-playbook-skills/tree/main/downloads).
